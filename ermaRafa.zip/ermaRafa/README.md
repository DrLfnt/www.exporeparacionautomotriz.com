/* Expo Reparación y Mantenimiento Automotriz */
# http://exporeparacionautomotriz.com

El sitio se esta desarrollando por Argenis Oldair Palacios @DrLfnt y por Rafael Ramírez @ElOrden13 en el año 2016
contacto http://disainco.com

El repositorio descargable esta acá: http://drlfnt.github.io/www.exporeparacionautomotriz.com